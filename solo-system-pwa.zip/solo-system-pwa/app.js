// ---------- تسجيل Service Worker للعمل بدون إنترنت ----------
if ("serviceWorker" in navigator) {
  window.addEventListener("load", () => {
    navigator.serviceWorker.register("service-worker.js").catch(() => {});
  });
}

// ---------- منطق المستويات ----------
const xpForLevel = (level) => 100 + (level - 1) * 40;

function levelFromTotalXP(totalXP) {
  let level = 1;
  let remaining = totalXP;
  while (remaining >= xpForLevel(level)) {
    remaining -= xpForLevel(level);
    level += 1;
  }
  return { level, xpIntoLevel: remaining, xpNeeded: xpForLevel(level) };
}

function rankFromLevel(level) {
  if (level >= 50) return { label: "S", color: "#facc15" };
  if (level >= 40) return { label: "A", color: "#f97316" };
  if (level >= 30) return { label: "B", color: "#a78bfa" };
  if (level >= 20) return { label: "C", color: "#38bdf8" };
  if (level >= 10) return { label: "D", color: "#4ade80" };
  return { label: "E", color: "#94a3b8" };
}

const todayStr = () => new Date().toISOString().slice(0, 10);
const daysBetween = (a, b) => Math.round((new Date(b) - new Date(a)) / 86400000);
const uid = () => Math.random().toString(36).slice(2, 10);

const STORAGE_KEY = "solo-system-state";

const DEFAULT_STATE = () => ({
  totalXP: 0,
  streak: 0,
  lastActiveDate: todayStr(),
  fixedQuests: [
    { id: uid(), title: "شرب 2 لتر ماء", xp: 10, done: false },
    { id: uid(), title: "30 دقيقة رياضة", xp: 20, done: false },
    { id: uid(), title: "قراءة 15 صفحة", xp: 15, done: false },
  ],
  variableQuests: [],
});

// ---------- تحميل / حفظ الحالة ----------
function loadState() {
  let loaded = null;
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) loaded = JSON.parse(raw);
  } catch (e) {
    loaded = null;
  }
  if (!loaded) loaded = DEFAULT_STATE();

  const today = todayStr();
  if (loaded.lastActiveDate !== today) {
    const gap = daysBetween(loaded.lastActiveDate, today);
    const allDoneYesterday =
      loaded.fixedQuests.length > 0 && loaded.fixedQuests.every((q) => q.done);
    loaded = {
      ...loaded,
      streak: gap === 1 && allDoneYesterday ? loaded.streak + 1 : 0,
      fixedQuests: loaded.fixedQuests.map((q) => ({ ...q, done: false })),
      variableQuests: [],
      lastActiveDate: today,
    };
  }
  return loaded;
}

function saveState() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
}

// ---------- الحالة العامة ----------
let state = loadState();
let prevLevel = levelFromTotalXP(state.totalXP).level;
let levelUpInfo = null;
let showFixedInput = false;
let showVarInput = false;

// ---------- تعديل الخبرة ----------
function applyXPChange(delta) {
  state.totalXP = Math.max(0, state.totalXP + delta);
  const newLevel = levelFromTotalXP(state.totalXP).level;
  if (newLevel > prevLevel) {
    levelUpInfo = { level: newLevel, rank: rankFromLevel(newLevel) };
  }
  prevLevel = newLevel;
}

function toggleFixed(id) {
  const q = state.fixedQuests.find((x) => x.id === id);
  applyXPChange(q.done ? -q.xp : q.xp);
  q.done = !q.done;
  saveState();
  render();
}

function toggleVar(id) {
  const q = state.variableQuests.find((x) => x.id === id);
  applyXPChange(q.done ? -q.xp : q.xp);
  q.done = !q.done;
  saveState();
  render();
}

function addFixed(title) {
  if (!title.trim()) return;
  state.fixedQuests.push({ id: uid(), title: title.trim(), xp: 10, done: false });
  showFixedInput = false;
  saveState();
  render();
}

function addVar(title) {
  if (!title.trim()) return;
  state.variableQuests.push({ id: uid(), title: title.trim(), xp: 15, done: false });
  showVarInput = false;
  saveState();
  render();
}

function removeFixed(id) {
  state.fixedQuests = state.fixedQuests.filter((x) => x.id !== id);
  saveState();
  render();
}

function removeVar(id) {
  state.variableQuests = state.variableQuests.filter((x) => x.id !== id);
  saveState();
  render();
}

// ---------- عناصر واجهة مساعدة ----------
function escapeHtml(str) {
  const div = document.createElement("div");
  div.textContent = str;
  return div.innerHTML;
}

function questRowHtml(q, kind) {
  return `
    <div class="quest-row ${q.done ? "done" : ""}" data-id="${q.id}" data-kind="${kind}">
      <button class="checkbox-btn ${q.done ? "checked" : ""}" data-action="toggle">${q.done ? "[✓]" : "[ ]"}</button>
      <div class="quest-title ${q.done ? "done" : ""}" data-action="toggle">${escapeHtml(q.title)}</div>
      <div class="quest-xp">+${q.xp}</div>
      <button class="remove-btn" data-action="remove">🗑</button>
    </div>`;
}

function addRowHtml(kind, placeholder) {
  return `
    <div class="add-row" data-kind="${kind}">
      <input type="text" placeholder="${placeholder}" data-role="add-input" />
      <button class="icon-btn-small" data-action="submit">+</button>
      <button class="icon-btn-small" data-action="cancel">✕</button>
    </div>`;
}

// ---------- الرسم الرئيسي ----------
function render() {
  const { level, xpIntoLevel, xpNeeded } = levelFromTotalXP(state.totalXP);
  const rank = rankFromLevel(level);
  const progressPct = Math.min(100, Math.round((xpIntoLevel / xpNeeded) * 100));

  const app = document.getElementById("app");
  app.innerHTML = `
    <div class="player-card">
      <div class="player-top">
        <div>
          <div class="eyebrow">[ الصياد ]</div>
          <div class="level-row">
            <span class="level-num">Lv.${level}</span>
            <span class="rank-badge" style="border-color:${rank.color};color:${rank.color}">رتبة ${rank.label}</span>
          </div>
        </div>
        <div class="streak-box" style="color:${state.streak > 0 ? "#fb923c" : "#4b5c73"}">
          🔥 <span>${state.streak}</span>
        </div>
      </div>
      <div class="xp-bar-outer"><div class="xp-bar-inner" style="width:${progressPct}%"></div></div>
      <div class="xp-label">${xpIntoLevel} / ${xpNeeded} XP</div>
    </div>

    <div class="section">
      <div class="section-header">
        <div>
          <div class="section-title">المهام اليومية الثابتة</div>
          <div class="section-subtitle">تتكرر كل يوم — عادات تبنيها</div>
        </div>
        <button class="icon-btn" id="add-fixed-btn">+</button>
      </div>
      <div id="fixed-list">
        ${showFixedInput ? addRowHtml("fixed", "اسم المهمة الثابتة...") : ""}
        ${
          state.fixedQuests.length === 0 && !showFixedInput
            ? `<div class="empty-hint">لا توجد مهام ثابتة بعد. أضف أول عادة يومية.</div>`
            : state.fixedQuests.map((q) => questRowHtml(q, "fixed")).join("")
        }
      </div>
    </div>

    <div class="section">
      <div class="section-header">
        <div>
          <div class="section-title">مهام اليوم</div>
          <div class="section-subtitle">تُحذف تلقائياً عند بداية يوم جديد</div>
        </div>
        <button class="icon-btn" id="add-var-btn">+</button>
      </div>
      <div id="var-list">
        ${showVarInput ? addRowHtml("var", "مهمة اليوم...") : ""}
        ${
          state.variableQuests.length === 0 && !showVarInput
            ? `<div class="empty-hint">لا توجد مهام لهذا اليوم. أضف ما تريد إنجازه.</div>`
            : state.variableQuests.map((q) => questRowHtml(q, "var")).join("")
        }
      </div>
    </div>

    ${
      levelUpInfo
        ? `
      <div class="modal-overlay" id="modal-overlay">
        <div class="modal">
          <div style="font-size:36px;margin-bottom:8px;">🛡️</div>
          <div class="modal-title">[ ارتقاء بالمستوى ]</div>
          <div class="modal-level">Lv.${levelUpInfo.level}</div>
          <div class="modal-rank" style="color:${levelUpInfo.rank.color}">الرتبة الحالية: ${levelUpInfo.rank.label}</div>
          <button class="modal-btn" id="modal-close-btn">متابعة</button>
        </div>
      </div>`
        : ""
    }
  `;

  attachEvents();
}

// ---------- ربط الأحداث ----------
function attachEvents() {
  const addFixedBtn = document.getElementById("add-fixed-btn");
  if (addFixedBtn) addFixedBtn.onclick = () => { showFixedInput = !showFixedInput; render(); };

  const addVarBtn = document.getElementById("add-var-btn");
  if (addVarBtn) addVarBtn.onclick = () => { showVarInput = !showVarInput; render(); };

  document.querySelectorAll(".quest-row").forEach((row) => {
    const id = row.getAttribute("data-id");
    const kind = row.getAttribute("data-kind");
    row.querySelectorAll('[data-action="toggle"]').forEach((el) => {
      el.onclick = () => (kind === "fixed" ? toggleFixed(id) : toggleVar(id));
    });
    row.querySelector('[data-action="remove"]').onclick = () =>
      kind === "fixed" ? removeFixed(id) : removeVar(id);
  });

  document.querySelectorAll(".add-row").forEach((rowEl) => {
    const kind = rowEl.getAttribute("data-kind");
    const input = rowEl.querySelector('[data-role="add-input"]');
    input.focus();
    const submit = () => (kind === "fixed" ? addFixed(input.value) : addVar(input.value));
    rowEl.querySelector('[data-action="submit"]').onclick = submit;
    rowEl.querySelector('[data-action="cancel"]').onclick = () => {
      if (kind === "fixed") showFixedInput = false;
      else showVarInput = false;
      render();
    };
    input.addEventListener("keydown", (e) => {
      if (e.key === "Enter") submit();
      if (e.key === "Escape") {
        if (kind === "fixed") showFixedInput = false;
        else showVarInput = false;
        render();
      }
    });
  });

  const overlay = document.getElementById("modal-overlay");
  if (overlay) {
    overlay.onclick = (e) => {
      if (e.target === overlay) { levelUpInfo = null; render(); }
    };
    document.getElementById("modal-close-btn").onclick = () => { levelUpInfo = null; render(); };
  }
}

render();
